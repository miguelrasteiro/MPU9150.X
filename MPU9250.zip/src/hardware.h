/* 
 * File:   hardware.h
 * Author: MiguelRasteiro
 *
 * Created on 25 de Agosto de 2014, 17:04
 */

#ifndef HARDWARE_H
#define	HARDWARE_H


#define SYS_FREQ (80000000L)                                       /**< CPU clock frequency */
#define FOSC       SYS_FREQ                                        /**< CPU clock frequency */
#define	GetPeripheralClock()	(SYS_FREQ/(1 << OSCCONbits.PBDIV))
#define	GetInstructionClock()	(SYS_FREQ)                         /**< Instructions frequency */
#define PBCLK       SYS_FREQ/2
#define Fsck        375000
#define BRG         100000//(PBCLK/2/Fsck)                         /**< I2C frequency */                     (FOSC)
#define UARTBAUDRATE 230400
        // For Timers
#define ONE_SECOND                    (FOSC/8)                  // 1s of PIC32 core timer ticks (== Hz)
#define MS_TO_CORE_TICKS(x)   ((UINT64)(x)*ONE_SECOND/1000)
#define CT_TICKS_SINCE(tick)   (ReadCoreTimer() - (tick))	// number of core timer ticks since "tick"

#define TIMER_1_INT_VECTOR 4                                       /**< Interruption Vector */

#define MPU_I2C I2C1



#endif	/* HARDWARE_H */

