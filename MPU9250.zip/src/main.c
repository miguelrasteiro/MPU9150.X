
#include <p32xxxx.h>
#include <plib.h>
//#include "pic_config.h"
#include "uart.h"
#include "hardware.h"
#include "i2c.h"
#include "margMPU.h"
#include "mpu9x50.h"

/** Configuration Bit settings
 * SYSCLK = 80 MHz (8MHz Crystal / FPLLIDIV * FPLLMUL / FPLLODIV)
 * PBCLK = 80 MHz (SYSCLK / FPBDIV)
 * Primary Osc w/PLL (XT+,HS+,EC+PLL)
 * WDT OFF
 * Other options are don't care
 */
#pragma config FPLLMUL = MUL_20, FPLLIDIV = DIV_2, FPLLODIV = DIV_1, FWDTEN = OFF
#pragma config POSCMOD = HS, FNOSC = PRIPLL, FPBDIV = DIV_1

#define DEFAULT_MPU_HZ  (50)

#define PI          3.14159265358979    /**< Define gyro sensitivity in use */
//#define Gyrodps     SENSITIVITY_500DPS  /**< Define gyro sensitivity in use */
//#define GyroRad     Gyrodps*PI/180      /**< Define gyro sensitivity in use in rad/s */
//#define AccG        SENSITIVITY_ACC_4G  /**< Define acc sensitivity in use */
//#define MagGauss    SENSITIVITY_MAG_2G  /**< Define mag sensitivity in use */
//#define Gravity     1/AccG              /**< Define gravity value in bits */


/*================================================================
                 G L O B A L   V A R I A B L E S
================================================================*/
UINT8 T1overflow = 1;


/*================================================================
             F U N C T I O N S   P R O T O T Y P E S
================================================================*/

void InitUART (void);
void InitTimer1 (void);
void mpu_test (void);

/**
 * Timer 1 ISR
 *  Interrupt Priority Level = 2
 *  Vector 4
 */
void __ISR(TIMER_1_INT_VECTOR, ipl2) _Timer1Handler(void) {
    // Clear the interrupt flag
    mT1ClearIntFlag();
    // Protection to timer overflow
    T1overflow ++;
}

/*================================================================
                   E N T R Y   P O I N T
================================================================*/
int main(void)
{
    // Variables
    UINT8   buf[1024];
    // Read RawValues

    unsigned int temptime;
    data_xyz gyro, acc, mag;
    long temperature;
    UINT8 data;
    float gyrox,gyroy,gyroz,accx,accy,accz,magx,magy,magz;
    float Gyro_dps,Mag_uT = 0.6;
    unsigned short Acc_G;
    float cycle_time, sampleFreq, time_elapsed = 0;


    InitUART();
    //OpenI2C1( I2C_EN, BRG );    //Enable I2C channel
    InitTimer1();
    i2c_init(MPU_I2C, MASTER, 0);

    // MPU initialization
    mpu_init();
    mpu_set_sensors(INV_XYZ_GYRO | INV_XYZ_ACCEL | INV_XYZ_COMPASS);
    AutoCalibrateAcc ();
    AutoCalibrateGyro();

    // Get Sensitivities accordingly to the initializations
    mpu_get_gyro_sens (&Gyro_dps);
    mpu_get_accel_sens( &Acc_G );

    WriteTimer1(0x00);  // Timer set to 0
    T1overflow = 1;

    while(1)
    {
        // Colocar em fun��o
        temptime = ReadTimer1(); // Reads time elapsed
        cycle_time = (float)((double) (temptime * T1overflow * 256 * 4) / PBCLK );// tempo = valortimer*overflow*prescaler*4/fosc ;

        if (cycle_time >= 0.01)
        {
            time_elapsed = time_elapsed + cycle_time;
            WriteTimer1(0x00);  // Timer set to 0
            T1overflow = 1;
            sampleFreq = 1/cycle_time;

            // Read sensors
            ReadGyroXYZ ( &gyro);
            ReadAccXYZ  ( &acc );
            ReadMagXYZ  ( &mag );

            gyro.x /=  Gyro_dps; gyro.y /=  Gyro_dps; gyro.z /=  Gyro_dps;
            acc.x  /=  Acc_G;    acc.y  /=  Acc_G;    acc.z  /=  Acc_G;
            mag.x  /=  Mag_uT;   mag.y  /=  Mag_uT;   mag.z  /=  Mag_uT;

            sprintf(buf,"I %.4f %.4f %.4f %.4f %.4f %.4f %.4f %.4f %.4f %.4f\n", gyrox, gyroy, gyroz, accx, accy, accz, magx, magy, magz, cycle_time);
            SendDataBuffer(buf, strlen(buf));
        }
    }
    return -1;
}

void InitUART(void){
    UARTConfigure(UART_MODULE_ID, UART_ENABLE_PINS_TX_RX_ONLY);
    UARTSetFifoMode(UART_MODULE_ID, UART_INTERRUPT_ON_TX_NOT_FULL | UART_INTERRUPT_ON_RX_NOT_EMPTY);
    UARTSetLineControl(UART_MODULE_ID, UART_DATA_SIZE_8_BITS | UART_PARITY_NONE | UART_STOP_BITS_1);
    UARTSetDataRate(UART_MODULE_ID, GetPeripheralClock(), UARTBAUDRATE);
    UARTEnable(UART_MODULE_ID, UART_ENABLE_FLAGS(UART_PERIPHERAL | UART_RX | UART_TX));
}


void InitTimer1 (void){
    OpenTimer1(T1_ON | T1_PS_1_256, 0xFFFF);
    ConfigIntTimer1(T1_INT_ON | T1_INT_PRIOR_2 | T1_INT_SUB_PRIOR_0);// Set up the core timer interrupt with a priority of 2 and zero sub-priority
    INTEnableSystemMultiVectoredInt(); // STEP 3. enable multi-vector interrupts
}


void mpu_test (void){

    unsigned short data;
    short raw_values[3]={0,0,0}, status;
    long temperature, gbias[3], abias[3];
    BYTE daat;
    unsigned char sensors, more;
    int result;

   // result = mpu_run_self_test(&gbias, &abias);

    i2c_read(MPU_ADDRESS, MPUREG_WHO_AM_I, 1, (BYTE *)&data);

    mpu_init();

    result = mpu_run_self_test(&gbias, &abias);

    mpu_set_sensors(INV_XYZ_GYRO | INV_XYZ_ACCEL | INV_XYZ_COMPASS);

    mpu_get_gyro_fsr   (&data);
    mpu_get_accel_fsr  (&data);
    mpu_get_compass_fsr(&data);
    mpu_get_sample_rate(&data);

    mpu_get_int_status (&status);

    result = mpu_read_fifo(raw_values, raw_values, &sensors, &more);

    i2c_read(0x0C, 0x00, 1, &daat);

    result = mpu_run_self_test(&gbias, &abias);

    mpu_get_gyro_reg   ( raw_values);
    mpu_get_accel_reg  ( raw_values);
    mpu_get_compass_reg( raw_values);
    mpu_get_temperature( temperature);


    result = mpu_run_self_test(&gbias, &abias);
}